BAYZEL BUSINESS MANAGER - OFFLINE INSTALLABLE WEB APP

For easiest upload from an Android phone, upload these FIVE files to the ROOT of your GitHub repository:
- index.html
- manifest.webmanifest
- service-worker.js
- icon-192.png
- icon-512.png

After publishing with GitHub Pages, open the HTTPS Pages address in Chrome on Android while online. Choose Install app (or Add to Home screen > Install). Open BAYZEL once while online so the service worker caches the app. After that, the app shell can open offline.

IMPORTANT: This is an early offline-capable prototype, not a production accounting system. Business records currently use browser localStorage. Do not clear Chrome/site data. Use the in-app backup feature regularly and store backup files somewhere safe. Native SQLite, secure staff login, multi-device sync, and Bluetooth receipt printing are not yet included.
